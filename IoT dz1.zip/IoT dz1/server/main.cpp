#include <stdio.h>      /* for printf(), fprintf() */
#include <winsock.h>    /* for socket(),... */
#include <stdlib.h>     /* for exit() */
#include <time.h>


#define RCVBUFSIZE 32   /* Size of receive buffer */


#define MAXPENDING 6    /* Maximum outstanding connection requests */

void DieWithError(const char *errorMessage);  /* Error handling function */

int HandleTCPClient1(int clntSocket, int brojac);   /* TCP client handling function */
int HandleTCPClient2(int clntSocket, int brojac);   /* TCP client handling function */
int HandleTCPClient3(int clntSocket, int brojac);   /* TCP client handling function */
int HandleTCPClient4(int clntSocket, int brojac);   /* TCP client handling function */
int HandleTCPClient5(int clntSocket, int brojac);   /* TCP client handling function */


 main(int argc, char *argv[])
{
    int servSock;                    /* Socket descriptor for server */
    int clntSock [5];                    /* Socket descriptor for client */
    struct sockaddr_in echoServAddr; /* Local address */
    struct sockaddr_in echoClntAddr; /* Client address */
    unsigned short echoServPort;     /* Server port */
    int clntLen;            /* Length of client address data structure */
    WSADATA wsaData;                 /* Structure for WinSock setup communication */
    char slovo;
    int msec;
    clock_t total_time;
	clock_t start = clock ();

    if (argc != 2)     /* Test for correct number of arguments */
    {
        fprintf(stderr, "Usage:  %s <Server Port>\n", argv[0]);
        exit(1);
    }

    echoServPort = atoi(argv[1]);  /* first arg:  Local port */

    if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0) /* Load Winsock 2.0 DLL */
    {
        fprintf(stderr, "WSAStartup() failed");
        exit(1);
    }

    /* Create socket for incoming connections */
    if ((servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
        DieWithError("socket() failed");

    /* Construct local address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));   /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                /* Internet address family */
    echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    echoServAddr.sin_port = htons(echoServPort);      /* Local port */

	
	/* Create socket for incoming connections */
    if ((servSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
       	DieWithError("socket() failed");

   	 /* Construct local address structure */
   	memset(&echoServAddr, 0, sizeof(echoServAddr));   /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                /* Internet address family */
    echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
   	echoServAddr.sin_port = htons(echoServPort);      /* Local port */
			
    /* Bind to the local address */
    if (bind(servSock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) < 0)
        DieWithError("bind() failed");
	
	
	
	for (int i=0; i<MAXPENDING-1; i++) /* don't Run forever */	
	{			

		/* Mark the socket so it will listen for incoming connections */
    	if (listen(servSock, MAXPENDING) < 0)
        	DieWithError("listen() failed");
    
        /* Set the size of the in-out parameter */
        clntLen = sizeof(echoClntAddr);

        /* Wait for a client to connect */
        if ((clntSock[i] = accept(servSock, (struct sockaddr *) &echoClntAddr, &clntLen)) < 0)
            DieWithError("accept() failed");

        /* clntSock is connected to a client! */	
		
   	
	    switch (i)
		{
			case 0: 
				printf("Handling client %d, %s\n", i+1, inet_ntoa(echoClntAddr.sin_addr));
				HandleTCPClient1(clntSock[i], i);
				break;
			case 1: 
				printf("Handling client %d, %s\n", i+1, inet_ntoa(echoClntAddr.sin_addr));
				HandleTCPClient2(clntSock[i], i);
				break;
			case 2:
				printf("Handling client %d, %s\n", i+1, inet_ntoa(echoClntAddr.sin_addr)); 
				HandleTCPClient3(clntSock[i], i);
				break;
			case 3: 
				printf("Handling client %d, %s\n", i+1, inet_ntoa(echoClntAddr.sin_addr));
				HandleTCPClient4(clntSock[i], i);
				break;
			case 4: 
				printf("Handling client %d, %s\n", i+1, inet_ntoa(echoClntAddr.sin_addr));
				HandleTCPClient5(clntSock[i], i);
				break; 
			default: break;
		
		}
		
    }
    
    total_time = clock () - start;
    msec = total_time * 1000 / CLOCKS_PER_SEC;
    
    printf("Time taken %d seconds %d milliseconds\n", msec/1000, msec%1000);
    
    printf ("Everything OK! Press 'q' to exit.\n");
    closesocket (servSock); 
    scanf ("%c", slovo);
    if (slovo == 'q')
    	exit (1);
    
    
}


int HandleTCPClient1(int clntSocket, int brojac)
{
    char echoBuffer [RCVBUFSIZE] ;        /* Buffer for echo string */
    int recvMsgSize;                    /* Size of received message */
    FILE *fp;
    int echoBufferLength;
    char myBuffer [RCVBUFSIZE+1];

	    
    	fp= fopen ("client1.txt", "w");
    	
    		/* Receive message from client */
    		if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        		DieWithError("recv() failed");
        	
        	
			fprintf (fp, "Redni broj klijenta: ");
			fprintf (fp, "%d\n", brojac);
			fprintf (fp, "  ID: ");
					
    		/* Send received string and receive again until end of transmission */
    		while (recvMsgSize > 0)      /* zero indicates end of transmission */
    		{
    	    	/* Echo message back to client */
    	    	if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
    	        	DieWithError("send() failed");	
    	        
    	        for (int k=0; k<recvMsgSize; k++)
    	    	{
    	    		myBuffer[k] = echoBuffer [k];
				}
				
				myBuffer[recvMsgSize]= '\0';
			
    	    	/* See if there is more data to receive */
    	    	if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE,0)) < 0)
    	    	    DieWithError("recv() failed");
    	    	    
    	    	fprintf (fp, "%s\n", myBuffer);
    		}
    	
		fclose (fp);
    	closesocket(clntSocket);    /* Close client socket */
    		
		
}


int HandleTCPClient2(int clntSocket, int brojac)
{
   char echoBuffer [RCVBUFSIZE] ;        /* Buffer for echo string */
    int recvMsgSize;                    /* Size of received message */
    FILE *fp;
    int echoBufferLength;
    char myBuffer [RCVBUFSIZE+1];

	    
    	fp= fopen ("client2.txt", "w");
    	
    		/* Receive message from client */
    		if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        		DieWithError("recv() failed");
        	
        	
			fprintf (fp, "Redni broj klijenta: ");
			fprintf (fp, "%d\n", brojac);
			fprintf (fp, "  ID: ");
					
    		/* Send received string and receive again until end of transmission */
    		while (recvMsgSize > 0)      /* zero indicates end of transmission */
    		{
    	    	/* Echo message back to client */
    	    	if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
    	        	DieWithError("send() failed");	
    	        
    	        for (int k=0; k<recvMsgSize; k++)
    	    	{
    	    		myBuffer[k] = echoBuffer [k];
				}
				
				myBuffer[recvMsgSize]= '\0';
			
    	    	/* See if there is more data to receive */
    	    	if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE,0)) < 0)
    	    	    DieWithError("recv() failed");
    	    	    
    	    	fprintf (fp, "%s\n", myBuffer);      	    	    
    		}
    	
		fclose (fp);
    	closesocket(clntSocket);    /* Close client socket */	
		
}

int HandleTCPClient3(int clntSocket, int brojac)
{
    char echoBuffer [RCVBUFSIZE] ;        /* Buffer for echo string */
    int recvMsgSize;                    /* Size of received message */
    FILE *fp;
    int echoBufferLength;
    char myBuffer [RCVBUFSIZE+1];

	    
    	fp= fopen ("client3.txt", "w");
    	
    		/* Receive message from client */
    		if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        		DieWithError("recv() failed");
        	
        	
			fprintf (fp, "Redni broj klijenta: ");
			fprintf (fp, "%d\n", brojac);
			fprintf (fp, "  ID: ");
					
    		/* Send received string and receive again until end of transmission */
    		while (recvMsgSize > 0)      /* zero indicates end of transmission */
    		{
    	    	/* Echo message back to client */
    	    	if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
    	        	DieWithError("send() failed");	
    	        
    	        for (int k=0; k<recvMsgSize; k++)
    	    	{
    	    		myBuffer[k] = echoBuffer [k];
				}
				
				myBuffer[recvMsgSize]= '\0';
			
    	    	/* See if there is more data to receive */
    	    	if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE,0)) < 0)
    	    	    DieWithError("recv() failed");
    	    	    
    	    	fprintf (fp, "%s\n", myBuffer);       	    	    
    		}
    	
		fclose (fp);
    	closesocket(clntSocket);    /* Close client socket */	
		
}


int HandleTCPClient4(int clntSocket, int brojac)
{
    char echoBuffer [RCVBUFSIZE] ;        /* Buffer for echo string */
    int recvMsgSize;                    /* Size of received message */
    FILE *fp;
    int echoBufferLength;
    char myBuffer [RCVBUFSIZE+1];

	    
    	fp= fopen ("client4.txt", "w");
    	
    			/* Receive message from client */
    		if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        		DieWithError("recv() failed");
        	
        	
			fprintf (fp, "Redni broj klijenta: ");
			fprintf (fp, "%d\n", brojac);
			fprintf (fp, "  ID: ");
					
    		/* Send received string and receive again until end of transmission */
    		while (recvMsgSize > 0)      /* zero indicates end of transmission */
    		{
    	    	/* Echo message back to client */
    	    	if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
    	        	DieWithError("send() failed");	
    	        
    	        for (int k=0; k<recvMsgSize; k++)
    	    	{
    	    		myBuffer[k] = echoBuffer [k];
				}
				
				myBuffer[recvMsgSize]= '\0';
			
    	    	/* See if there is more data to receive */
    	    	if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE,0)) < 0)
    	    	    DieWithError("recv() failed");
    	    	    
    	    	fprintf (fp, "%s\n", myBuffer);       	    	    
    		}
    	
		fclose (fp);
    	closesocket(clntSocket);    /* Close client socket */
    		
		
}

int HandleTCPClient5(int clntSocket, int brojac)
{
    char echoBuffer [RCVBUFSIZE] ;        /* Buffer for echo string */
    int recvMsgSize;                    /* Size of received message */
    FILE *fp;
    int echoBufferLength;
    char myBuffer [RCVBUFSIZE+1];

	    
    	fp= fopen ("client5.txt", "w");
    	
    		/* Receive message from client */
    		if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE, 0)) < 0)
        		DieWithError("recv() failed");
        	
        	
			fprintf (fp, "Redni broj klijenta: ");
			fprintf (fp, "%d\n", brojac);
			fprintf (fp, "  ID: ");
					
    		/* Send received string and receive again until end of transmission */
    		while (recvMsgSize > 0)      /* zero indicates end of transmission */
    		{
    	    	/* Echo message back to client */
    	    	if (send(clntSocket, echoBuffer, recvMsgSize, 0) != recvMsgSize)
    	        	DieWithError("send() failed");	
    	        
    	        for (int k=0; k<recvMsgSize; k++)
    	    	{
    	    		myBuffer[k] = echoBuffer [k];
				}
				
				myBuffer[recvMsgSize]= '\0';
			
    	    	/* See if there is more data to receive */
    	    	if ((recvMsgSize = recv(clntSocket, echoBuffer, RCVBUFSIZE,0)) < 0)
    	    	    DieWithError("recv() failed");
    	    	    
    	    	fprintf (fp, "%s\n", myBuffer);     	    	    
    		}
    	
		fclose (fp);
    	closesocket(clntSocket);    /* Close client socket */

		
}

void DieWithError(const char *errorMessage)
{
    fprintf(stderr,"%s: %d\n", errorMessage, WSAGetLastError());
    exit(1);
}




