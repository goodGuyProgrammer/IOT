#include <iostream>


#include <stdio.h>      /* for printf(), fprintf() */
#include <winsock2.h>    /* for socket(),... */
#include <stdlib.h>     /* for exit() */
#include <string.h>
#include <math.h>
#include <time.h>

#define RCVBUFSIZE 32   /* Size of receive buffer */
#define pi 3.1415

//   set  Project-> Project Options -> parameters -lws2_32
// ipconfig/all, tlenet IPaddress 17,13



void DieWithError(const char *errorMessage);  /* Error handling function */
char* float_to_ascii (float f, int precision);

int main(int argc, char *argv[])
{
    int sock;                        /* Socket descriptor */
    struct sockaddr_in echoServAddr; /* Echo server address */
    unsigned short echoServPort;     /* Echo server port */
    char *servIP;                    /* Server IP address (dotted quad) */
    char *echoString;                /* String to send to echo server */
    char echoTxString [RCVBUFSIZE];                /* String to send to echo server */
    char echoBuffer[RCVBUFSIZE];     /* Buffer for echo string */
    char echoRxBuffer[RCVBUFSIZE];     /* Buffer for echo string */
    int echoStringLen;               /* Length of string to echo */
    int bytesRcvd, totalBytesRcvd;   /* Bytes read in single recv() and total bytes read */
    WSADATA wsaData;                 /* Structure for WinSock setup communication */
    char *clientID;
    int prvi =1;
    int first_sample = 1;
    int msec =0;
	int waitTime, totTime;
    int trigger = 12; /* 12 msec */
    clock_t  difference, start, end, before, waitStart, waitStop; 
        
    float sample;
    FILE *fp;
    
    start = clock (); /* tick-toc tick-toc */

    if ((argc < 3) || (argc > 4))    /* Test for correct number of arguments */
    {
        fprintf(stderr, "Usage: %s <Server IP> <Echo Word> [<Echo Port>]\n", argv[0]);
        exit(1);
    }

    servIP = argv[1];             /* First arg: server IP address (dotted quad) */
    
    if (argc == 4)
        echoServPort = atoi(argv[3]); /* Use given port, if any */
    else
        echoServPort = 7;  /* otherwise, 7 is the well-known port for the echo service */

    if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0) /* Load Winsock 2.0 DLL */
    {
        fprintf(stderr, "WSAStartup() failed");
        exit(1);
    }

    /* Create a reliable, stream socket using TCP */
    if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
        DieWithError("socket() failed");

    /* Construct the server address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));     /* Zero out structure */
    echoServAddr.sin_family      = AF_INET;             /* Internet address family */
    echoServAddr.sin_addr.s_addr = inet_addr(servIP);   /* Server IP address */
    echoServAddr.sin_port        = htons(echoServPort); /* Server port */
   
   
   waitStart = clock();
    /* Establish the connection to the echo server */
    while (connect(sock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) < 0)
    {
    	/* wait */
	} 
	waitStop = clock () - waitStart;
	waitTime = waitStop * 1000/ CLOCKS_PER_SEC;
	printf("Time taken to connect %d seconds %d milliseconds\n", waitTime/1000, waitTime%1000);
	
	printf ("Connected to server\n");  
        
    fp = fopen ("received.txt", "w");

	for (int i=0; i<101; i++)
	{
		if (prvi)
		{	
			echoString = argv[2]; /* ID */
			echoStringLen = strlen(echoString);          /* Determine input length */
			prvi = 0;	/* da prvi put salje samo ID klijenta koji se zadaje preko terminala */	
		}
		
		else
		{	
			if (first_sample)
			{
				first_sample = 0;
				before = clock (); /* merenje prvog intervala krece ovde */
			}
										
			do {
				difference = clock() - before;
 				msec = difference * 1000/ CLOCKS_PER_SEC;
			} while (msec<trigger);
			
			before = clock (); /* odavde krece svaki sledeci odbirak */
			
			sample = 2*sin(pi*(i-1)*12./180);
			echoString = float_to_ascii (sample, 4);
    		//echoString = gcvt (sample, 4, echoString);
			echoStringLen = strlen(echoString);          /* Determine input length */
    	}

    	/* Send the string, including the null terminator, to the server */
    	if (send(sock, echoString, echoStringLen, 0) != echoStringLen)
        	DieWithError("send() sent a different number of bytes than expected");

    	/* Receive the same string back from the server */
    	totalBytesRcvd = 0;
    	printf("Received: ");                /* Setup to print the echoed string */
    	while (totalBytesRcvd < echoStringLen)
    	{
        	/* Receive up to the buffer size (minus 1 to leave space for 
           	a null terminator) bytes from the sender */
        	if ((bytesRcvd = recv(sock, echoRxBuffer, RCVBUFSIZE - 1, 0)) <= 0)
            	DieWithError("recv() failed or connection closed prematurely");
		
        	totalBytesRcvd += bytesRcvd;   /* Keep tally of total bytes */
        	echoRxBuffer[bytesRcvd] = '\0';  /* Add \0 so printf knows where to stop */
        	fprintf(fp, "%s", echoRxBuffer);            /* Print the echo buffer */
        	printf("%s", echoRxBuffer);
    	}	

		
    	fprintf(fp, "\n");    /* Print a final linefeed */
    	printf("\n");
	
	}
	
	end = clock () - start;
	totTime = end * 1000/ CLOCKS_PER_SEC;
	
	printf ("Completed successfuly!\n");
	printf("Total time taken %d seconds %d milliseconds\n", totTime/1000, totTime%1000); 
	printf("Time taken to connect %d seconds %d milliseconds\n", waitTime/1000, waitTime%1000);
    closesocket(sock);
    WSACleanup();  /* Cleanup Winsock */
	fclose (fp);

return 0;
    
}

void DieWithError(const char *errorMessage)
{
    fprintf(stderr,"%s: %d\n", errorMessage, WSAGetLastError());
    exit(1);
}

char* float_to_ascii (float f, int precision) /* Ova funkcija je preuzeta sa GitHub-a, zbog malfunctioning-a gcvt() funkcije */

{
	
	float  ff = f;
	char *str;
	int a,b,c,k,l=0,m,i=0,j;
	
	// check for negetive float
	if(f<0.0)
	{
		
		str[i++]='-';
		f*=-1;
	}
	
	a=floor (f);	// extracting whole number
	f-=a;	// extracting decimal part
	k = precision;
	
	// number of digits in whole number
	while(k>-1)
	{
		l = pow(10,k);
		m = a/l;
		if(m>0)
		{
			break;
		}
	k--;
	}

	// number of digits in whole number are k+1
	
	/*
	extracting most significant digit i.e. right most digit , and concatenating to string
	obtained as quotient by dividing number by 10^k where k = (number of digit -1)
	*/
	
	for(l=k+1;l>0;l--)
	{
		b = pow(10,l-1);
		c = a/b;
		str[i++]=c+48;
		a%=b;
	}
	str[i++] = '.';
	
	/* extracting decimal digits till precision */

	for(l=0;l<precision;l++)
	{
		f*=10.0;
		b = f;
		str[i++]=b+48;
		f-=b;
	}

	str[i]='\0';

	return str;
}


