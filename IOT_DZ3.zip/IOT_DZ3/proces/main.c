#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MQTTClient.h"
#include <time.h>
#include <math.h>

#define ADDRESS     "broker.hivemq.com:1883"
#define CLIENTID1   "INPUT"
#define CLIENTID2	"OUTPUT"
#define IN_TOPIC    "iks"
#define OUT_TOPIC   "trenutniPritisak"
#define PAYLOAD     "Hello World!"
#define QOS         0
#define TIMEOUT     10L

 char inpayloadptr[20];
 char outpayloadptr[20];
 char* inbuffer;
 char* outbuffer;
 char* oxiliaryBuffer;
 
volatile MQTTClient_deliveryToken deliveredtoken1; 
volatile MQTTClient_deliveryToken deliveredtoken2;

char* float_to_ascii (float f, int precision);

void delivered1(void *context, MQTTClient_deliveryToken dt)
{
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken1 = dt;
}

int msgarrvd1(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
    int i;
   
    printf("Message arrived\n");
    printf("     topic: %s\n", topicName);
    printf("   message: ");

    inbuffer= message->payload;
    
	strcpy (inpayloadptr, inbuffer);			/*  kopiraj u staticni buffer */

    
    inpayloadptr[message->payloadlen] = '\0';  /* zatvori ga nultim karakterom */
    
    for(i=0; i<message->payloadlen; i++)
    {
        putchar(inpayloadptr[i]);
    }
    putchar('\n');
    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

void connlost1(void *context, char *cause)
{
    printf("\nConnection lost\n");
    printf("     cause: %s\n", cause);
}

/*****************  Dovde su podesavanja za ulaz  *****************/

void delivered2(void *context, MQTTClient_deliveryToken dt)
{
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken2 = dt;
}

int msgarrvd2(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
    int i;
   
    printf("Message arrived\n");
    printf("     topic: %s\n", topicName);
    printf("   message: ");

    outbuffer= message->payload;
       
    for(i=0; i<message->payloadlen; i++)
    {
        putchar(outpayloadptr[i]);
    }
    putchar('\n');
    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

void connlost2(void *context, char *cause)
{
    printf("\nConnection lost\n");
    printf("     cause: %s\n", cause);
}


int main(int argc, char* argv[])
{
    MQTTClient client2;
    MQTTClient_connectOptions conn_opts2 = MQTTClient_connectOptions_initializer;
    MQTTClient_message pubmsg2 = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token2;
    int rc2;

    MQTTClient_create(&client2, ADDRESS, CLIENTID2,
        MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts2.keepAliveInterval = 20;
    conn_opts2.cleansession = 1;

    MQTTClient_setCallbacks(client2, NULL, connlost2, msgarrvd2, delivered2);

    if ((rc2 = MQTTClient_connect(client2, &conn_opts2)) != MQTTCLIENT_SUCCESS)
    {
        printf("Failed to connect, return code %d\n", rc2);
        exit(EXIT_FAILURE);
    }
    pubmsg2.payload = PAYLOAD; /* ovo ce se menjati during the time */
    pubmsg2.payloadlen = strlen(outpayloadptr);
    pubmsg2.qos = QOS;
    pubmsg2.retained = 0;
    
    /********************  Dovde je za izlaz *******************/

	/********************  Odavde je za ulaz ********************/
	
	MQTTClient client1;
    MQTTClient_connectOptions conn_opts1 = MQTTClient_connectOptions_initializer;
    int rc1;
    char ch;

    MQTTClient_create(&client1, ADDRESS, CLIENTID1,
        MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts1.keepAliveInterval = 20;
    conn_opts1.cleansession = 1;

    MQTTClient_setCallbacks(client1, NULL, connlost1, msgarrvd1, delivered1);

    if ((rc1 = MQTTClient_connect(client1, &conn_opts1)) != MQTTCLIENT_SUCCESS)
    {
        printf("Failed to connect, return code %d\n", rc1);
        exit(EXIT_FAILURE);
    }
    printf("Subscribing to input topic\n\n Press Q<Enter> to quit\n\n");
    MQTTClient_subscribe(client1, IN_TOPIC, QOS);						/* Obavezan subscribe na topic x[n]  */
	
	/*********************  Ovde je gotovo sa svim podesavanjima  ************************************/
	
	int msec = 0, trigger = 1000;
	clock_t before, difference;
	float yt, yp=0.0, xp=0.0, xt;
	
	before = clock ();
	for (;;)
	{
		do 
		{
			difference = clock () - before;
			msec = difference*1000/CLOCKS_PER_SEC;
		} while (msec<trigger);
		
		before = clock ();
		
		xt = atof (inpayloadptr);
		yt = (xt+xp + 19*yp)/21.0f;
		
		oxiliaryBuffer = float_to_ascii (yt, 4); /* konvertuj u odlazni buffer */
		
		strcpy (outpayloadptr, oxiliaryBuffer); /* kopiraj u stacionarni buffer */
		pubmsg2.payload = outpayloadptr; 
		pubmsg2.payloadlen = strlen(outpayloadptr);				    
		
        MQTTClient_publishMessage(client2, OUT_TOPIC, &pubmsg2, &token2);		/* publish-uj podatak */
    	while(deliveredtoken2 != token2);  /* cekaj da se zavrsi */
    	printf("Message with delivery token %d delivered\n", token2);
    	before = clock ();
    	
		xp=xt;
		yp= yt; 
    	
	}
	
	MQTTClient_disconnect(client1, 10000);
    MQTTClient_destroy(&client1);
	
	MQTTClient_disconnect(client2, 10000);
    MQTTClient_destroy(&client2);
    return rc2;
}

char* float_to_ascii (float f, int precision) /* Ova funkcija je preuzeta sa GitHub-a, zbog malfunctioning-a gcvt() funkcije */

{
	
	float  ff = f;
	char *str;
	int a,b,c,k,l=0,m,i=0,j;
	
	// check for negetive float
	if(f<0.0)
	{
		
		str[i++]='-';
		f*=-1;
		//i++;
	}
	
	
	a=floor (f);	// extracting whole number
	f-=a;	// extracting decimal part
	k = precision;
	
	if (a==0)
	{
		str[i++]= 48;
		//i++;
		k==-1;
	}
	// number of digits in whole number
	while(k>-1)
	{
		l = pow(10,k);
		m = a/l;
		if(m>0)
		{
			break;
		}
	k--;
	}

	// number of digits in whole number are k+1
	
	/*
	extracting most significant digit i.e. right most digit , and concatenating to string
	obtained as quotient by dividing number by 10^k where k = (number of digit -1)
	*/
	
	for(l=k+1;l>0;l--)
	{
		b = pow(10,l-1);
		c = a/b;
		str[i++]=c+48;
		a%=b;
	}
	str[i++] = '.';
	
	/* extracting decimal digits till precision */

	for(l=0;l<precision;l++)
	{
		f*=10.0;
		b = f;
		str[i++]=b+48;
		f-=b;
	}

	str[i]='\0';

	return str;
}
