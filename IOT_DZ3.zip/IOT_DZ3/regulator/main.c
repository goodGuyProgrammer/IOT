#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MQTTClient.h"
#include <math.h>
#include <time.h>

#define ADDRESS         "broker.hivemq.com:1883"
#define CLIENTID1       "trenutnaVrednost"
#define CLIENTID2       "zadataVrednost"
#define CLIENTID3       "izlazRegulatora"
#define IN_TOPIC1       "trenutniPritisak"
#define IN_TOPIC2       "zadatiPritisak"
#define OUT_TOPIC		"iks"
#define PAYLOAD         "Hello World!"
#define QOS              0
#define TIMEOUT          10L

char trenBuffer[20];
char zadBuffer [20];
char iksBuffer [20];

volatile MQTTClient_deliveryToken deliveredtoken1;
volatile MQTTClient_deliveryToken deliveredtoken2;
volatile MQTTClient_deliveryToken deliveredtoken3;

void delivered1(void *context, MQTTClient_deliveryToken dt)
{
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken1 = dt;
}

void delivered2(void *context, MQTTClient_deliveryToken dt)
{
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken2 = dt;
}

int msgarrvd1(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
    int i;
    char* payloadptr;

    printf("Message arrived\n");
    printf("     topic: %s\n", topicName);
    printf("   message: ");

    payloadptr = message->payload;
    strcpy (trenBuffer, payloadptr);
    for(i=0; i<message->payloadlen; i++)
    {
        putchar(*payloadptr++);
    }
    putchar('\n');
    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

int msgarrvd2(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
    int i;
    char* payloadptr;

    printf("Message arrived\n");
    printf("     topic: %s\n", topicName);
    printf("   message: ");

    payloadptr = message->payload;
    strcpy (zadBuffer, payloadptr);
    for(i=0; i<message->payloadlen; i++)
    {
        putchar(*payloadptr++);
    }
    putchar('\n');
    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

void connlost1(void *context, char *cause)
{
    printf("\nConnection lost\n");
    printf("     cause: %s\n", cause);
}

void connlost2(void *context, char *cause)
{
    printf("\nConnection lost\n");
    printf("     cause: %s\n", cause);
}
/*************************  Dovde su podesavanja na ulazne topic-e  ************************************/


void delivered3(void *context, MQTTClient_deliveryToken dt)
{
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken3 = dt;
}

int msgarrvd3(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
    int i;
    char* payloadptr;

    printf("Message arrived\n");
    printf("     topic: %s\n", topicName);
    printf("   message: ");

    payloadptr = message->payload;
    for(i=0; i<message->payloadlen; i++)
    {
        putchar(*payloadptr++);
    }
    putchar('\n');
    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);
    return 1;
}

void connlost3(void *context, char *cause)
{
    printf("\nConnection lost\n");
    printf("     cause: %s\n", cause);
}

/************************************** gotovo sa podesavanjima ***********************************************/


int main(int argc, char* argv[])
{
    MQTTClient client1;
    MQTTClient_connectOptions conn_opts1 = MQTTClient_connectOptions_initializer;
    int rc1;
    int ch;

    MQTTClient_create(&client1, ADDRESS, CLIENTID1,
        MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts1.keepAliveInterval = 20;
    conn_opts1.cleansession = 1;

    MQTTClient_setCallbacks(client1, NULL, connlost1, msgarrvd1, delivered1);

    if ((rc1 = MQTTClient_connect(client1, &conn_opts1)) != MQTTCLIENT_SUCCESS)
    {
        printf("Failed to connect, return code %d\n", rc1);
        exit(EXIT_FAILURE);
    }
    printf("Subscribing to topic %s\nfor client %s using QoS%d\n\n"
           "Press Q<Enter> to quit\n\n", IN_TOPIC1, CLIENTID1, QOS);
    MQTTClient_subscribe(client1, IN_TOPIC1, QOS);
    
    /*********************************  Dovde je za ptvi topic, tj. y(t)  ****************************************************/
    
    MQTTClient client2;
    MQTTClient_connectOptions conn_opts2 = MQTTClient_connectOptions_initializer;
    int rc2;

    MQTTClient_create(&client2, ADDRESS, CLIENTID2,
        MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts2.keepAliveInterval = 20;
    conn_opts2.cleansession = 1;

    MQTTClient_setCallbacks(client2, NULL, connlost2, msgarrvd2, delivered2);

    if ((rc2 = MQTTClient_connect(client2, &conn_opts2)) != MQTTCLIENT_SUCCESS)
    {
        printf("Failed to connect, return code %d\n", rc2);
        exit(EXIT_FAILURE);
    }
    printf("Subscribing to topic %s\nfor client %s using QoS%d\n\n"
           "Press Q<Enter> to quit\n\n", IN_TOPIC2, CLIENTID2, QOS);
    MQTTClient_subscribe(client2, IN_TOPIC2, QOS);
    
    /******************************   Dovde je za drugi topic, tj. Y zadato ************************************************/
    
    
    MQTTClient client3;
    MQTTClient_connectOptions conn_opts3 = MQTTClient_connectOptions_initializer;
    MQTTClient_message pubmsg3 = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token3;
    int rc3;

    MQTTClient_create(&client3, ADDRESS, CLIENTID3,
        MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts3.keepAliveInterval = 20;
    conn_opts3.cleansession = 1;

    MQTTClient_setCallbacks(client3, NULL, connlost3, msgarrvd3, delivered3);

    if ((rc3 = MQTTClient_connect(client3, &conn_opts3)) != MQTTCLIENT_SUCCESS)
    {
        printf("Failed to connect, return code %d\n", rc3);
        exit(EXIT_FAILURE);
    }
    pubmsg3.payload = iksBuffer; /* ovo ce se menjati ili 0 ili 100 */
    
    pubmsg3.qos = QOS;
    pubmsg3.retained = 0;
    deliveredtoken3 = 0;
    
    /***********************  Dovde je za izlazni topic, tj. x[n]  **********************************************************/
	
	int yz;
	float yt, dozvRazlika= 1.0;
	int x;
	clock_t  before, difference;
	int msec=0, trigger; // = 1000;
	
	before = clock ();
	for (;;)
	{
		yt = atof (trenBuffer);
		yz = atoi (zadBuffer);
		
		
		if (yt > (yz + dozvRazlika))
		{
			x=0;
			trigger=5;
		} 
		else if (yt< (yz - dozvRazlika)){
			x = 100;
			trigger =5;
		}
		else continue;
		
		do {
			difference = clock() - before;
			msec = difference*1000/CLOCKS_PER_SEC;
		} while (msec<trigger);
		
		before = clock();		
		itoa (x, iksBuffer, 10);
		iksBuffer[19] = '\0';
		pubmsg3.payload= iksBuffer;
		pubmsg3.payloadlen = strlen(iksBuffer);
			
		MQTTClient_publishMessage(client3, OUT_TOPIC, &pubmsg3, &token3);
    	printf("Waiting for publication of %s\n"
    	    "on topic %s for client with ClientID: %s\n",
       		iksBuffer, OUT_TOPIC, CLIENTID3);
    	while(deliveredtoken3 != token3);	
	}
    
    MQTTClient_disconnect(client1, 10000);
    MQTTClient_destroy(&client1);
    
    MQTTClient_disconnect(client2, 10000);
    MQTTClient_destroy(&client2);
    
    MQTTClient_disconnect(client3, 10000);
    MQTTClient_destroy(&client3);
    
    return rc3;
}
