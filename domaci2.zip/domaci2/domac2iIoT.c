/*
Example for G2C_Sensor Click

    Date          : Apr 2019.
    Author        : MikroE Team

Test configuration STM32 :

    MCU              : STM32F407VG
    Dev. Board       : Clicker 2 for STM32
    ARM Compiler ver : v6.1.0.0
*/

#include "math.h"

#include "Click_G2C_Sensor_types.h"
#include "Click_G2C_Sensor_config.h"

#include "__g2csensor_driver.h"

#define WIFI_NETWORK_SSID       "ETF_mag"
#define WIFI_NETWORK_PASS       "pit@jg@zdu"

#define G2C_DEVICE_ID           "pbzso4abfsdyy65d"
#define G2C_DEVICE_PASS         "ae4af2f0-54ab-4f2b-a38c-9a8714332613"


    unsigned short int time=0;

void systemInit()
{
    // Initialize Sensor Peripherals

   // mikrobus_gpioInit( _MIKROBUS2, _MIKROBUS_INT_PIN, _GPIO_INPUT );
    //mikrobus_i2cInit( _MIKROBUS2, _HDC1000_I2C_CFG );

    // G2C Peripherals Initialization

    mikrobus_gpioInit( _MIKROBUS1, _MIKROBUS_RST_PIN, _GPIO_OUTPUT );
    mikrobus_uartInit( _MIKROBUS1, _G2C_UART_CFG );
    mikrobus_logInit( _MIKROBUS3, 9600 );

    Delay_ms( 100 );
    mikrobus_logWrite( "System peripherals initialized.", _LOG_LINE );
}

void applicationInit()
{
    // Initialize Sensor Driver

   // hdc1000_i2cDriverInit( (T_HDC1000_P)&_MIKROBUS2_GPIO, (T_HDC1000_P)&_MIKROBUS2_I2C, _HDC1000_ADDR );
   // hdc1000_defaultConfiguration();

    // G2C Driver Initializaton

    g2csensor_uartDriverInit( (T_G2CSENSOR_P)&_MIKROBUS1_GPIO, (T_G2CSENSOR_P)&_MIKROBUS1_UART );
    mikrobus_logWrite( "G2C driver initialized.", _LOG_LINE );
    Delay_ms( 5000 );

    g2csensor_enableDevice();
    mikrobus_logWrite( "G2C device enabled.", _LOG_LINE );
    Delay_ms( 5000 );

    g2csensor_connectNetwork( WIFI_NETWORK_SSID , WIFI_NETWORK_PASS );
    mikrobus_logWrite( "G2C connected to network.", _LOG_LINE );
    Delay_ms( 5000 );

    g2csensor_connectBroker( G2C_DEVICE_ID , G2C_DEVICE_PASS );
    mikrobus_logWrite( "G2C connected to broker.", _LOG_LINE );
    Delay_ms( 5000 );
}
void applicationTask()
{
    float NivoBuke;
    float BrzinaVetra;
     int RandNumber;

    uint8_t logTime[64];
    uint8_t logNB[64];
    uint8_t logBV[64];

    // MY Simulated Measurement

    NivoBuke = 65 + rand()%20;
    RandNumber = rand ()%68;
    BrzinaVetra = 1.8 + RandNumber*0.03;

    FloatToStr(time, logTime);
    time++;

    mikrobus_logWrite( "Time : ", _LOG_TEXT );
    mikrobus_logWrite( logTime, _LOG_TEXT );
    mikrobus_logWrite( " s", _LOG_LINE );
    FloatToStr(NivoBuke, logNB);
    mikrobus_logWrite( "Nivo buke : ", _LOG_TEXT );
    mikrobus_logWrite( logNB, _LOG_TEXT );
    mikrobus_logWrite( " dB", _LOG_LINE );


    FloatToStr(BrzinaVetra, logBV);
    mikrobus_logWrite( "Brzina vetra : ", _LOG_TEXT );
    mikrobus_logWrite( logBV, _LOG_TEXT );
    mikrobus_logWrite( " m/s", _LOG_LINE );



    // Commit data and send to cloud
    // g2csensor_commitData( "TESTTIME_T", logTime);
    g2csensor_commitData( "Nivo_buke", logNB);
    g2csensor_commitData( "Brzina_vetra", logBV);

    g2csensor_publishData();
}

void main()
{
    systemInit();
    applicationInit();

    for (;;)
    {
        applicationTask();
    }
}