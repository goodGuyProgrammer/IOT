#include "Click_HDC1000_types.h"


const uint32_t _HDC1000_I2C_CFG[ 1 ] = 
{
	100000
};
