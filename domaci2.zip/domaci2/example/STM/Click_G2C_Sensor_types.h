#ifndef _G2CSENSOR_T_
#define _G2CSENSOR_T_

#include "stdint.h"

#ifndef _G2CSENSOR_H_

#define T_G2CSENSOR_P const uint8_t* 

#endif
#endif