/*
Example for G2C_Sensor Click

    Date          : Apr 2019.
    Author        : MikroE Team

Test configuration STM32 :
    
    MCU              : STM32F407VG
    Dev. Board       : Clicker 2 for STM32
    ARM Compiler ver : v6.1.0.0
*/

#include "Click_HDC1000_config.h"

#include "Click_G2C_Sensor_types.h"
#include "Click_G2C_Sensor_config.h"

#include "__g2csensor_driver.h"

#define WIFI_NETWORK_SSID       "MikroE Public"
#define WIFI_NETWORK_PASS       "mikroe.guest"

#define G2C_DEVICE_ID           "o5wpb9yqava294xu"
#define G2C_DEVICE_PASS         "d212015b-c9ac-459b-8c02-0325d585f0f6"

void systemInit()
{
    // Initialize Sensor Peripherals

    mikrobus_gpioInit( _MIKROBUS2, _MIKROBUS_INT_PIN, _GPIO_INPUT );
    mikrobus_i2cInit( _MIKROBUS2, _HDC1000_I2C_CFG );

    // G2C Peripherals Initialization

    mikrobus_gpioInit( _MIKROBUS1, _MIKROBUS_RST_PIN, _GPIO_OUTPUT );
    mikrobus_uartInit( _MIKROBUS1, _G2C_UART_CFG );
    mikrobus_logInit( _MIKROBUS3, 9600 );

    Delay_ms( 100 );
    mikrobus_logWrite( "System peripherals initialized.", _LOG_LINE );
}

void applicationInit()
{
    // Initialize Sensor Driver

    hdc1000_i2cDriverInit( (T_HDC1000_P)&_MIKROBUS2_GPIO, (T_HDC1000_P)&_MIKROBUS2_I2C, _HDC1000_ADDR );
    hdc1000_defaultConfiguration();

    // G2C Driver Initializaton

    g2csensor_uartDriverInit( (T_G2CSENSOR_P)&_MIKROBUS1_GPIO, (T_G2CSENSOR_P)&_MIKROBUS1_UART );
    mikrobus_logWrite( "G2C driver initialized.", _LOG_LINE );
    Delay_ms( 5000 );
    
    g2csensor_enableDevice();
    mikrobus_logWrite( "G2C device enabled.", _LOG_LINE );
    Delay_ms( 5000 );
    
    g2csensor_connectNetwork( WIFI_NETWORK_SSID , WIFI_NETWORK_PASS );
    mikrobus_logWrite( "G2C connected to network.", _LOG_LINE );
    Delay_ms( 5000 );
    
    g2csensor_connectBroker( G2C_DEVICE_ID , G2C_DEVICE_PASS );
    mikrobus_logWrite( "G2C connected to broker.", _LOG_LINE );
    Delay_ms( 5000 );
}

void applicationTask()
{
    float temperature;
    
    uint8_t logT[64];

    // Temperature Measurement

    temperature = hdc1000_getTemperature();

    FloatToStr(temperature, logT);
    mikrobus_logWrite( "Measured T : ", _LOG_TEXT );
    mikrobus_logWrite( logT, _LOG_TEXT );
    mikrobus_logWrite( " C", _LOG_LINE );

    // Commit data and send to cloud

    g2csensor_commitData( "HDC1000_T", logT );
    g2csensor_publishData();
}

void main()
{
    systemInit();
    applicationInit();

    for (;;)
    {
        applicationTask();
    }
}