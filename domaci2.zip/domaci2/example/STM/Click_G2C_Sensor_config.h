#include "Click_G2C_Sensor_types.h"

const uint32_t _G2C_UART_CFG[ 4 ] =
{
    57600,
    _UART_8_BIT_DATA,
    _UART_NOPARITY, 
    _UART_ONE_STOPBIT
};