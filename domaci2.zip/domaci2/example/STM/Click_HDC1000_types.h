#ifndef _HDC1000_T_
#define _HDC1000_T_

#include "stdint.h"

#ifndef _HDC1000_H_

#define T_HDC1000_P const uint8_t* 

#endif
#endif