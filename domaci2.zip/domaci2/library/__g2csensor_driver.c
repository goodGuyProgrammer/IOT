/*
    __g2csensor_driver.c

-----------------------------------------------------------------------------

  This file is part of mikroSDK.

  Copyright (c) 2017, MikroElektonika - http://www.mikroe.com

  All rights reserved.

----------------------------------------------------------------------------- */

#include "__g2csensor_driver.h"
#include "__g2csensor_hal.c"

/* ------------------------------------------------------------------- MACROS */

#define LOCAL_BUFFER_SIZE           (256)

/* ---------------------------------------------------------------- VARIABLES */

#ifdef   __G2CSENSOR_DRV_I2C__
static uint8_t _slaveAddress;
#endif

/* -------------------------------------------- PRIVATE FUNCTION DECLARATIONS */

static void sendCommand ( uint8_t *buff );

/* --------------------------------------------------------- PUBLIC FUNCTIONS */

#ifdef   __G2CSENSOR_DRV_SPI__

void g2csensor_spiDriverInit(T_G2CSENSOR_P gpioObj, T_G2CSENSOR_P spiObj)
{
    hal_spiMap( (T_HAL_P)spiObj );
    hal_gpioMap( (T_HAL_P)gpioObj );

    // ... power ON
    // ... configure CHIP
}

#endif
#ifdef   __G2CSENSOR_DRV_I2C__

void g2csensor_i2cDriverInit(T_G2CSENSOR_P gpioObj, T_G2CSENSOR_P i2cObj, uint8_t slave)
{
    _slaveAddress = slave;
    hal_i2cMap( (T_HAL_P)i2cObj );
    hal_gpioMap( (T_HAL_P)gpioObj );

    // ... power ON
    // ... configure CHIP
}

#endif
#ifdef   __G2CSENSOR_DRV_UART__

void g2csensor_uartDriverInit(T_G2CSENSOR_P gpioObj, T_G2CSENSOR_P uartObj)
{
    hal_uartMap( (T_HAL_P)uartObj );
    hal_gpioMap( (T_HAL_P)gpioObj );

    hal_gpio_rstSet( 1 );
    Delay_100ms();
    hal_gpio_rstSet( 0 );
    Delay_100ms();
    hal_gpio_rstSet( 1 );
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
}

#endif

/* ----------------------------------------------------------- IMPLEMENTATION */

void g2csensor_writeByte(uint8_t input)
{
    hal_uartWrite(input);
}

uint8_t g2csensor_readByte()
{
    return hal_uartRead();
}

uint8_t g2csensor_byteReady()
{
    return hal_uartReady();
}

void g2csensor_enableDevice ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "AT+CEN=1");
    sendCommand(buf);
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
}

void g2csensor_disableDevice ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "AT+CEN=0");
    sendCommand(buf);
    Delay_1sec();
}

void g2csensor_resetDevice ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "AT+RST");
    sendCommand(buf);
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
}

void g2csensor_enableEcho ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "ATE1");
    sendCommand(buf);
    Delay_1sec();
}

void g2csensor_disableEcho ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "ATE0");
    sendCommand(buf);
    Delay_1sec();
}

void g2csensor_connectNetwork ( uint8_t *ssid, uint8_t *pass )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];

    // Compose and send "Set network credentials" command

    strcpy(buf, "AT+NWCR=");
    strcat(buf, "\"");
    strcat(buf, ssid);
    strcat(buf, "\"");
    strcat(buf, ",");
    strcat(buf, "\"");
    strcat(buf, pass);
    strcat(buf, "\"");
    sendCommand(buf);
    Delay_1sec();

    // Send "Connect to network" command

    memset(buf, 0, LOCAL_BUFFER_SIZE);
    strcpy(buf, "AT+NWC=1");
    sendCommand(buf);
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
}

void g2csensor_disconnectNetwork ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "AT+NWC=0");
    sendCommand(buf);
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();   
}

void g2csensor_connectBroker ( uint8_t *devid, uint8_t *pass )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];

    // Compose and send "Set broker credentials" command

    strcpy(buf, "AT+BRCR=");
    strcat(buf, "\"");
    strcat(buf, devid);
    strcat(buf, "\"");
    strcat(buf, ",");
    strcat(buf, "\"");
    strcat(buf, pass);
    strcat(buf, "\"");
    sendCommand(buf);
    Delay_1sec();

    // Send "Connect to broker" command

    memset(buf, 0, LOCAL_BUFFER_SIZE);
    strcpy(buf, "AT+BRC=1");
    sendCommand(buf);
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
}

void g2csensor_disconnectBroker ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "AT+BRC=0");
    sendCommand(buf);
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
}

void g2csensor_commitData ( uint8_t *ref, uint8_t *val )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "AT+DSET=");
    strcat(buf, "\"");
    strcat(buf, ref);
    strcat(buf, "\"");
    strcat(buf, ",");
    strcat(buf, "\"");
    strcat(buf, val);
    strcat(buf, "\"");
    sendCommand(buf);
    Delay_1sec();
}

void g2csensor_publishData ( void )
{
    uint8_t buf[ LOCAL_BUFFER_SIZE ];
 
    strcpy(buf, "AT+PUB");
    sendCommand(buf);
    Delay_1sec();
    Delay_1sec();
    Delay_1sec();
}

/* --------------------------------------------- PRIVATE FUNCTION DEFINITIONS */

static void sendCommand ( uint8_t *buff )
{
    uint16_t idx;

    for (idx = 0; buff[idx] != 0; ++idx)
    {
        hal_uartWrite(buff[idx]);
    }

    hal_uartWrite(13);
}

/* -------------------------------------------------------------------------- */
/*
  __g2csensor_driver.c

  Copyright (c) 2017, MikroElektonika - http://www.mikroe.com

  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. All advertising materials mentioning features or use of this software
   must display the following acknowledgement:
   This product includes software developed by the MikroElektonika.

4. Neither the name of the MikroElektonika nor the
   names of its contributors may be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY MIKROELEKTRONIKA ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL MIKROELEKTRONIKA BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------------------- */